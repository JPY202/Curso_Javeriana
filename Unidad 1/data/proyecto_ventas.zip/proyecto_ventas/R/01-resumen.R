# Calcula el total de ventas por tienda y lo guarda en output/
ventas <- read.csv("data/ventas.csv")

total <- aggregate(ventas ~ tienda, data = ventas, FUN = sum)
print(total)

write.csv(total, "output/total_por_tienda.csv", row.names = FALSE)
