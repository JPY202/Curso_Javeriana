Proyecto de ejemplo del curso Métodos y Simulación Estadística.
Los datos son ficticios.
1. Abra proyecto_ventas.Rproj con doble clic.
2. Ejecute R/01-resumen.R.
3. Abra informe.Rmd y haga clic en Knit.
